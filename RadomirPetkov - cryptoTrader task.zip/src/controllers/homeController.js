
const homeController = async (req, res) => {

res.render("./home")
}
module.exports = homeController

