
exports.jwtPrivateKey = `fgasp13vss1cfsdas`